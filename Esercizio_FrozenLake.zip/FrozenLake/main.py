import gym
import random
import numpy as np
import torch
from collections import deque

from config import DQN_MIN_REPLAY, DQN_TARGET_UPDATE
from deep_q_learning import DQNAgent
from frozen_lake import generate_random_map

from config import (
    MAX_EPISODE_STEPS, NUM_EPISODES, SEED)


def evaluate(agent, env, n_episodes=100):
    """
    Valuta l'agente su n_episodes senza esplorazione (ε≈0) e restituisce
    il tasso di successo medio.
    """
    successes = 0
    for _ in range(n_episodes):
        state, _ = env.reset()
        done = False
        while not done:
            action = agent.greedy_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated
            state = next_state
            if done and reward > 0:
                successes += 1
    return successes / n_episodes


def main():
    # Imposta seed
    random.seed(SEED)
    np.random.seed(SEED)
    torch.manual_seed(SEED)

    # Genera mappa 8x8 e la fissa
    fixed_map = generate_random_map(size=8, p=0.8, seed=SEED)
    env = gym.make(
        "CustomFrozenLake-v1",
        desc=fixed_map,
        is_slippery=True, # Provare sia con che senza scivolamento
        render_mode="human"
    )

    state_size = env.observation_space.n
    action_size = env.action_space.n

    # Inizializza agente DQN
    agent = DQNAgent(state_size, action_size, seed=SEED)
    # Seed del buffer con percorso ottimale

    # Buffer per metriche su finestra mobile da 100 episodi
    reward_window = deque(maxlen=100)
    success_window = deque(maxlen=100)

    for episode in range(1, NUM_EPISODES + 1):
        state, _ = env.reset()
        total_reward = 0
        done = False

        for _step in range(MAX_EPISODE_STEPS):
            action = agent.select_action(state)
            next_state, reward, terminated, truncated, _ = env.step(action)
            done = terminated or truncated

            # Salvataggio transizione e update DQN
            agent.store_transition(state, action, reward, next_state, done)
            agent.update()

            state = next_state
            total_reward += reward
            if done:
                break

        # Registra performance
        reward_window.append(total_reward)
        success_window.append(int(total_reward > 0))

        if episode % 100 == 0:
            avg_r = np.mean(reward_window)
            succ_rate = sum(success_window) / len(success_window) * 100
            print(
                f"Episode {episode}: avg reward (last100) = {avg_r:.2f}, "
                f"success rate = {succ_rate:.1f}%"
            )

    # Valutazione finale su 100 episodi
    final_rate = evaluate(agent, env)
    print(f"Final success rate over 100 episodes: {final_rate * 100:.1f}%")

    env.close()


if __name__ == "__main__":
    main()